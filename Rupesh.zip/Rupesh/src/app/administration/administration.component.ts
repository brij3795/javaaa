import { Component, OnInit } from '@angular/core';
import { UserService } from '../userregister/user.service';
import { User } from '../model/user';
import { BloodRequestService } from '../bloodrequest/bloodrequest.service';
import { BloodRequest } from '../model/bloodrequest';
import { Router } from '@angular/router';
import { AdminAuthenticationService } from '../home/admin.authentication.service';


@Component({
  selector: 'app-administration',
  templateUrl: './administration.component.html',
  styleUrls: ['./administration.component.css']
})
export class AdministrationComponent implements OnInit {

  administration: string = 'Administration';

  showuserlist: boolean = false;
  showbloodrequestlist: boolean = false;
  bloodrequests: BloodRequest;

  constructor(private userService: UserService, private bloodRequestService: BloodRequestService,
    private adminAuthenticationService: AdminAuthenticationService,
    private router: Router) { }

  users: User[];

  ngOnInit() {
    if (!this.adminAuthenticationService.isUserLoggedIn()) {
      this.router.navigate(['admin-login'])
    }
  }

  showUserList(): void {
    if (this.showuserlist == false) {
      this.userService.getUserList().subscribe(data => {
        this.users = data;
      })
      this.showuserlist = true;
    }
    else {
      this.showuserlist = false;
    }
  }

  showBloodRequestList(): void {
    if (this.showbloodrequestlist == false) {
      this.bloodRequestService.getBloodRequestList().subscribe(data => {
        this.bloodrequests = data;
      })
      this.showbloodrequestlist = true;
    }
    else {
      this.showbloodrequestlist = false;
    }
  }

  logoutAdmin() {
    if (this.adminAuthenticationService.logoutAdmin()) {
      this.router.navigate([''])
    }
  }

  sendRequest(bloodrequest: BloodRequest) {
    this.userService.sendRequestToAllUsers(bloodrequest)
      .subscribe(data => {
        console.log(data)
      },
        error => console.log(error));
    window.alert("Blood requirement request sent successfully!")
  }

}  