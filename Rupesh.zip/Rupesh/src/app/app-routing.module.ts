import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserregisterComponent } from './userregister/userregister.component';
import { HomeComponent } from './home/home.component';
import { BloodrequestComponent } from './bloodrequest/bloodrequest.component';
import { AdministrationComponent } from './administration/administration.component';
import { LoginComponent } from './login/login.component';
import { UserHomeComponent } from './user-home/user-home.component';
import { AboutUsComponent } from './about-us/about-us.component';


const routes: Routes = [
  { path: 'admin-login', component: HomeComponent },
  { path: 'admin-home', component: AdministrationComponent },
  { path: 'user-home', component: UserHomeComponent },
  { path: 'user-login', component: LoginComponent },
  { path: 'blood-request', component: BloodrequestComponent },
  { path: 'about-us', component: AboutUsComponent },
  { path: 'user-login/user-register', component: UserregisterComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
