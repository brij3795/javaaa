import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../model/user';
import { BloodRequest } from '../model/bloodrequest';
import { UserLogin } from '../model/user.login';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private baseUrl = 'http://localhost:8080/user/';

  constructor(private http: HttpClient) { }

  createUser(user: User): Observable<User> {
    return this.http.post<User>(`${this.baseUrl}` + 'createuser', user);
  }

  getUserList(): Observable<any> {
    return this.http.get<User[]>(`${this.baseUrl}` + 'getallusers');
  }

  sendRequestToAllUsers(bloodrequest: object): Observable<object> {
    return this.http.post(`${this.baseUrl}` + 'sendRequestToAllUsers', bloodrequest);
  }

  getBloodRequestForUser(): Observable<object> {
    let user = sessionStorage.getItem('username')
    return this.http.get<BloodRequest>(`${this.baseUrl}` + 'getbloodrequestforuser/' + user);
  }

  verifyUser(user: User): Observable<User> {
    return this.http.post<User>(`${this.baseUrl}` + 'verifyuser', user);
  }

  isUserLoggedIn() {
    let user = sessionStorage.getItem('username')
    return !(user === null)
  }

  logOut() {
    sessionStorage.removeItem('username')
  }

  loggedUserName() {
    return sessionStorage.getItem('username')
  }

  loggedUserEmail() {
    return sessionStorage.getItem('useremail')
  }

  acceptBloodRequest(useremail: string, bloodrequest: BloodRequest): Observable<any> {
    return this.http.put<User>(`${this.baseUrl}` + 'acceptbloodrequest/' + useremail, bloodrequest);
  }

}