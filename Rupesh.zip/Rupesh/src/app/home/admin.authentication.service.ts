import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AdminLogin } from '../model/admin.login';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class AdminAuthenticationService {

    private baseUrl = 'http://localhost:8080/admin/';

    constructor(private http: HttpClient) { }

    verifyAdmin(adminLogin: AdminLogin): Observable<AdminLogin> {
        return this.http.post<AdminLogin>(`${this.baseUrl}` + 'verifyAdmin', adminLogin);
    }

    isUserLoggedIn() {
        let user = sessionStorage.getItem('adminusername')
        return !(user === null)
    }

    logoutAdmin() {
        sessionStorage.removeItem('adminusername')
        return true
    }

}
