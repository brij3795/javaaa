export class UserLogin {

    userLoginEmail: string;
    userLoginPassword: string;

}