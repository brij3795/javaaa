export class BloodRequest{

    patient_name: string;
    patient_dateofbirth: string;
    patient_gender: string;
    patient_phone: string;
    patient_bloodgroup: string;
    patient_hospital: string;
    accepted: boolean;

}