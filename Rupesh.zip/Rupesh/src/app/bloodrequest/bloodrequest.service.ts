import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BloodRequest } from '../model/bloodrequest';

@Injectable({
  providedIn: 'root'
})
export class BloodRequestService {

  private baseUrl = 'http://localhost:8080/bloodrequest/';

  constructor(private http: HttpClient) { }

  createBloodRequest(bloodrequest: object): Observable<object> {
    return this.http.post(`${this.baseUrl}` + 'createbloodrequest', bloodrequest);
  }


  getBloodRequestList(): Observable<any> {  
    return this.http.get<BloodRequest[]>(`${this.baseUrl}`+'getallbloodrequest');  
  }  

  acceptBloodRequest(bloodrequest: BloodRequest): Observable<BloodRequest>{
    return this.http.post<BloodRequest>(`${this.baseUrl}`+'acceptBloodRequest', bloodrequest);
  }

}