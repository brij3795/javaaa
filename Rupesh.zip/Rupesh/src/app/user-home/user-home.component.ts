import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../userregister/user.service';
import { BloodRequestService } from '../bloodrequest/bloodrequest.service';
import { error } from '@angular/compiler/src/util';

@Component({
  selector: 'app-user-home',
  templateUrl: './user-home.component.html',
  styleUrls: ['./user-home.component.css']
})
export class UserHomeComponent implements OnInit {

  showBloodRequestFlag: boolean = false;
  bloodRequests: any;
  loggedUser: string;

  constructor(private router: Router,
    private userService: UserService,
    private bloodRequestService: BloodRequestService) { }

  ngOnInit() {

    this.loggedUser = this.userService.loggedUserName()

    if (!this.userService.isUserLoggedIn()) {
      this.router.navigate(['user-login'])
    }
    console.log("haa")

  }

  onSubmit() {
    this.userService.logOut()
    this.router.navigate([''])
  }

  showBloodRequest() {
    if (this.showBloodRequestFlag == false) {
      this.getBloodRequests()
      this.showBloodRequestFlag = true
    } else {
      this.showBloodRequestFlag = false
    }
  }

  acceptRequest(bloodrequest) {
    this.bloodRequestService.acceptBloodRequest(bloodrequest)
      .subscribe(data => {
        console.log(data)
      }, error => console.log(error))

    this.userService.acceptBloodRequest(this.userService.loggedUserEmail(), bloodrequest)
      .subscribe(data => {
        console.log(data)
        window.alert("Thanks for accepting request!")
        this.refreshBloodRequest()
      }, error => console.log(error))
  }

  refreshBloodRequest() {
    this.getBloodRequests()
    this.showBloodRequestFlag = true
  }

  getBloodRequests() {
    this.userService.getBloodRequestForUser()
      .subscribe(data => {
        this.bloodRequests = data
      },
        error => console.log(error)
      )
  }

}
