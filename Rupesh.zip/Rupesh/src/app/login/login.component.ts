import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { User } from 'src/app/model/user';
import { UserService } from '../userregister/user.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  user: User;

  loginUserData = {}
  invalidLogin: boolean = false;

  constructor(private router: Router,
    private userService: UserService) { }


  userloginform = new FormGroup({
    username: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required]),
  });

  userLogin() {
    this.user = new User();
    this.user.userEmail = this.userloginform.get('username').value;
    this.user.userPassword = this.userloginform.get('password').value;
    this.checkLogin();
  }

  ngOnInit() {
    if (this.userService.isUserLoggedIn()) {
      this.router.navigate(['user-home']);
    }
  }

  async checkLogin() {

    this.userService.verifyUser(this.user).subscribe(data => {

      this.user = data;

      if (this.user != null) {
        sessionStorage.setItem('username', this.user.userFirstName)
        sessionStorage.setItem('useremail', this.user.userEmail)
        console.log(this.user.userFirstName)
        this.router.navigate(['user-home'])
      } else {
        window.alert("Email or Password is not correct! Please try again.")
      }
      console.log(this.user)

    }, error => console.log(error))

  }

}
