package com.cg.repo;

import org.springframework.data.repository.CrudRepository;


import com.cg.entity.Patient;

public interface PatientRepo  extends CrudRepository<Patient, Integer>{

}
