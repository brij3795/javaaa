package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.BloodRequest;
import com.cg.entity.User;
import com.cg.repo.UserRepo;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepo userRepo;

	@Override
	public User addUser(User u) {
		return userRepo.save(u);
	}

	@Override
	public List<User> getUser() {
		return (List<User>) userRepo.findAll();
	}

	@Override
	public User sendRequestToUser(BloodRequest bloodRequest) {
		List<User> users = userRepo.findByUserBloodGroup(bloodRequest.getPatientBloodGroup());

		for (User user : users) {
			List<BloodRequest> userBloodRequests = user.getBloodRequests();
			if (userBloodRequests.isEmpty()) {
				user.getBloodRequests().add(bloodRequest);
			} else {
				List<BloodRequest> newBloodRequestList = new ArrayList<BloodRequest>();
				for (BloodRequest userBloodRequest : userBloodRequests) {
					if (!userBloodRequest.getFirstName().equals(bloodRequest.getFirstName())) {
						newBloodRequestList.add(bloodRequest);
					}
				}
				userBloodRequests.addAll(newBloodRequestList);
			}
			updateUser(user);
		}
		return null;
	}

	private void updateUser(User user) {
		userRepo.save(user);
	}

}
