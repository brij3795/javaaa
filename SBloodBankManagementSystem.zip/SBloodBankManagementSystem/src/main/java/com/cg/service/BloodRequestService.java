package com.cg.service;

import java.util.List;

import com.cg.entity.BloodRequest;

public interface BloodRequestService {

	List<BloodRequest> getBloodRequest();

}
