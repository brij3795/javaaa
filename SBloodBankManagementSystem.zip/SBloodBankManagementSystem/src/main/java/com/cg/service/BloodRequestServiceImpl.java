package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.BloodRequest;
import com.cg.repo.BloodRequestRepo;

@Service
public class BloodRequestServiceImpl implements BloodRequestService{

	@Autowired
	BloodRequestRepo bloodRequestRepo;
	
	@Override
	public List<BloodRequest> getBloodRequest() {
		return (List<BloodRequest>) bloodRequestRepo.findAll();
	}

}
