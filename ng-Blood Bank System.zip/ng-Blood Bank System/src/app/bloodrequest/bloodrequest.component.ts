import { Component, OnInit } from '@angular/core';
import { Patient } from '../model/patientdetails';
import { Router } from '@angular/router';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-bloodrequest',
  templateUrl: './bloodrequest.component.html',
  styleUrls: ['./bloodrequest.component.css']
})
export class BloodrequestComponent implements OnInit {


  patientBArr:Patient[]=[];
  patientb:Patient;
  constructor(private router: Router, private service: ServiceService) { }

  ngOnInit() {

    this.service.getBloodRequest().subscribe( res => {
      this.patientBArr = res;
      JSON.stringify(this.patientBArr);
      console.log(this.patientBArr);
    });
  }

}
